package com.example.sadgodzflutter1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
